#include "Common.h"
#include "ListP.h"
#include "ListPTest.h"

int main()
{
    ::ListPTest();
}