﻿#include <iostream>
#include "Common.h"
#include "ListP.h"

using namespace std;

Element* newElement(int value);

ListP* newPList() {
	ListP* list = new ListP;
	list->first = NULL;
	list->last = NULL;
	list->rozmiar = 0;
	return list;
}

void destroyPList(ListP* list) {
	if (list != NULL) {
		while (list->first != NULL) {
			Element* curr = list->first;
			if (list->first == list->last) list->first = NULL;
			else list->first = list->first->next;
			delete curr;
		}
		delete list;
	}
}

void addToPList(ListP* list, int value) {
	Element* newElem = newElement(value);
	if (list->first == NULL) {
		list->first = newElem;
		list->last = newElem;
	}
	else {
		list->last->next = newElem;
		list->last = newElem;
	}
	list->rozmiar++;
}

Element* search(ListP* list, int value) {
	Element* curr = list->first;
	while (curr != NULL) {
		if (curr->value == value) {
			return curr;
		}
		curr = curr->next;
	}
	return NULL;
}

int getFromPList(ListP* list, int index) {
	if (index < 0 || index >= list->rozmiar) {
		return NaN;
	}
	Element* curr = list->first;
	for (int i = 0; i < index; ++i) {
		curr = curr->next;
	}
	return curr->value;
}

Element* newElement(int value) {
	Element* element = new Element;
	element->value = value;
	element->next = NULL;
	return element;
}

int removeFromPList(ListP* list, int index) {
	Element* curr = list->first;
	int i = 0;
	Element* prev = NULL;
	while (curr != NULL && i < index) {
		prev = curr;
		curr = curr->next;
		i++;
	}
	int value;
	if (curr == NULL) { //Będzie null jeśli lista jest pusta
		list->last = prev;
		value = NaN;
	}
	else { 
		if (prev != NULL) { //Sprawdzant czy to nie pierwszy element listy		
			prev->next = curr->next;			
		}
		else {
			list->first = curr->next;
		}		
		if (curr->next == NULL) { //Jak koniec kolejki
			list->last = prev;
		}
		value = curr->value;
		list->rozmiar--;
		delete curr;
	}
	return value;
}

int sizeP(ListP* list) {
	if (list!=NULL)
		return list->rozmiar;
	return NaN;
}

auto_ptr<IteratorP> getPIterator(ListP* list) {
	IteratorP* iterator = new IteratorP;
	iterator->list = list;
	iterator->curr = list->first;
	iterator->counter = 0;
	return auto_ptr<IteratorP>(iterator);
}

int iterateP(IteratorP* iterator) {
	if (iterator->curr == NULL) {
		return NaN;
	}
	int value = iterator->curr->value;
	iterator->curr = iterator->curr->next;
	iterator->counter++;
	return value;
}
